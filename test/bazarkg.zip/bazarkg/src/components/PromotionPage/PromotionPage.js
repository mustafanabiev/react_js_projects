import React from 'react';
import './PromotionPage.css';
import './reset.css'
import Footer from "../ThreeComponents/Footer/Footer";

const PromotionPage = () => {
    return (
        <div>
            <header className="header">
                <div className="header_top">
                    <div className="container">
                        <ul className="header_lang">
                            <li><a href="#">Русский</a></li>
                            <li>
                                <a href="#"><img src="img-Promotion/room_black_24dp 1.svg" alt=""/>Ош</a>
                            </li>
                            <li><a href="#">Бесплатная доставка</a></li>
                            <li><a href="#">Продавцам</a></li>
                        </ul>
                    </div>
                </div>
                <div className="container">
                    <nav className="header_nav">
                        <div className="logo">
                            <img src="img-Promotion/logo.svg" alt=""/>
                            <h2>Online <span>Bazar</span></h2>
                        </div>
                        <ul className="header_menu">
                            <li><a href="/">Главная</a></li>
                            <li className="active"><a href="/aaaa">Акция</a></li>
                            <li><a href="#">Бренд</a></li>
                            <li><a href="#">Магазины</a></li>
                            <li><a href="#">О нас</a></li>
                            <li><a href="#">Контакты</a></li>
                        </ul>
                        <ul className="header_icons">
                            <li>
                                <a href="#"><img src="img-Promotion/Vector (2).svg" alt=""/></a>
                            </li>
                            <li>
                                <a href="#"><img src="img-Promotion/Vector (1).svg" alt=""/></a>
                            </li>
                            <li>
                                <a href="#"><img src="img-Promotion/Vector.svg" alt=""/></a>
                            </li>
                            <li>
                                <a href="#"><img src="img-Promotion/burger.svg" alt=""/></a>
                            </li>
                        </ul>
                    </nav>
                </div>
                <div className="header_banner">
                    <div className="container">
                        <div className="header_info">
                            <h1>Скидки одежду</h1>
                            <p>
                                Распродажи и скидки в розничных и <br/>
                                интернет-магазинах одежды и обув
                            </p>
                            <div className="header_img">
                                <img src="img-Promotion/Group 72.svg" alt=""/>
                            </div>
                            <a href="#">КУПИТЬ СЕЙЧАС</a>
                            <div className="header_block">
                                <img src="img-Promotion/Arrow 3.svg" alt=""/>
                                <div className="header_ellipses">
                                    <div className="header_ellipse"></div>
                                    <div className="header_ellipse header_active"></div>
                                    <div className="header_ellipse"></div>
                                    <div className="header_ellipse"></div>
                                    <div className="header_ellipse"></div>
                                </div>
                                <img src="img-Promotion/Arrow 2.svg" alt=""/>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <section className="product">
                <div className="container">
                    <div className="product_info">
                        <h2>Акции</h2>
                        <div className="product_nav">
                            <ul className="product_menu">
                                <li><a href="#">Все продукты</a></li>
                                <li><a href="#">Мужчины</a></li>
                                <li><a href="#">Женщины</a></li>
                                <li><a href="#">Мальчики</a></li>
                                <li><a href="#">Девочками</a></li>
                                <li><a href="#">Ребёнка</a></li>
                            </ul>
                            <div className="product_filter">
                                <img src="img-Promotion/Filtr.svg" alt=""/>
                                Фильтр
                            </div>
                        </div>
                        <div className="product_wrap">
                            <div className="product_block">
                                <div className="product_inblock">
                                    <div className="product_promotion">20%</div>
                                </div>
                                <div className="product_price">
                                    <h4>12000с</h4>
                                    <h4>9600с</h4>
                                </div>
                                <h3>Футболка / CHANEL</h3>
                                <p>Brand-Mixx</p>
                            </div>
                            <div className="product_block">
                                <div className="product_inblock">
                                    <div className="product_promotion">20%</div>
                                </div>
                                <div className="product_price">
                                    <h4>12000с</h4>
                                    <h4>9600с</h4>
                                </div>
                                <h3>Футболка / CHANEL</h3>
                                <p>Brand-Mixx</p>
                            </div>
                            <div className="product_block">
                                <div className="product_inblock">
                                    <div className="product_promotion">20%</div>
                                </div>
                                <div className="product_price">
                                    <h4>12000с</h4>
                                    <h4>9600с</h4>
                                </div>
                                <h3>Футболка / CHANEL</h3>
                                <p>Brand-Mixx</p>
                            </div>
                            <div className="product_block">
                                <div className="product_inblock">
                                    <div className="product_promotion">20%</div>
                                </div>
                                <div className="product_price">
                                    <h4>12000с</h4>
                                    <h4>9600с</h4>
                                </div>
                                <h3>Футболка / CHANEL</h3>
                                <p>Brand-Mixx</p>
                            </div>
                            <div className="product_block">
                                <div className="product_inblock">
                                    <div className="product_promotion">20%</div>
                                </div>
                                <div className="product_price">
                                    <h4>12000с</h4>
                                    <h4>9600с</h4>
                                </div>
                                <h3>Футболка / CHANEL</h3>
                                <p>Brand-Mixx</p>
                            </div>
                            <div className="product_block">
                                <div className="product_inblock">
                                    <div className="product_promotion">20%</div>
                                </div>
                                <div className="product_price">
                                    <h4>12000с</h4>
                                    <h4>9600с</h4>
                                </div>
                                <h3>Футболка / CHANEL</h3>
                                <p>Brand-Mixx</p>
                            </div>
                            <div className="product_block">
                                <div className="product_inblock">
                                    <div className="product_promotion">20%</div>
                                </div>
                                <div className="product_price">
                                    <h4>12000с</h4>
                                    <h4>9600с</h4>
                                </div>
                                <h3>Футболка / CHANEL</h3>
                                <p>Brand-Mixx</p>
                            </div>
                            <div className="product_block">
                                <div className="product_inblock">
                                    <div className="product_promotion">20%</div>
                                </div>
                                <div className="product_price">
                                    <h4>12000с</h4>
                                    <h4>9600с</h4>
                                </div>
                                <h3>Футболка / CHANEL</h3>
                                <p>Brand-Mixx</p>
                            </div>
                            <div className="product_block">
                                <div className="product_inblock">
                                    <div className="product_promotion">20%</div>
                                </div>
                                <div className="product_price">
                                    <h4>12000с</h4>
                                    <h4>9600с</h4>
                                </div>
                                <h3>Футболка / CHANEL</h3>
                                <p>Brand-Mixx</p>
                            </div>
                            <div className="product_block">
                                <div className="product_inblock">
                                    <div className="product_promotion">20%</div>
                                </div>
                                <div className="product_price">
                                    <h4>12000с</h4>
                                    <h4>9600с</h4>
                                </div>
                                <h3>Футболка / CHANEL</h3>
                                <p>Brand-Mixx</p>
                            </div>
                            <div className="product_block">
                                <div className="product_inblock">
                                    <div className="product_promotion">20%</div>
                                </div>
                                <div className="product_price">
                                    <h4>12000с</h4>
                                    <h4>9600с</h4>
                                </div>
                                <h3>Футболка / CHANEL</h3>
                                <p>Brand-Mixx</p>
                            </div>
                            <div className="product_block">
                                <div className="product_inblock">
                                    <div className="product_promotion">20%</div>
                                </div>
                                <div className="product_price">
                                    <h4>12000с</h4>
                                    <h4>9600с</h4>
                                </div>
                                <h3>Футболка / CHANEL</h3>
                                <p>Brand-Mixx</p>
                            </div>
                            <div className="product_block">
                                <div className="product_inblock">
                                    <div className="product_promotion">20%</div>
                                </div>
                                <div className="product_price">
                                    <h4>12000с</h4>
                                    <h4>9600с</h4>
                                </div>
                                <h3>Футболка / CHANEL</h3>
                                <p>Brand-Mixx</p>
                            </div>
                            <div className="product_block">
                                <div className="product_inblock">
                                    <div className="product_promotion">20%</div>
                                </div>
                                <div className="product_price">
                                    <h4>12000с</h4>
                                    <h4>9600с</h4>
                                </div>
                                <h3>Футболка / CHANEL</h3>
                                <p>Brand-Mixx</p>
                            </div>
                            <div className="product_block">
                                <div className="product_inblock">
                                    <div className="product_promotion">20%</div>
                                </div>
                                <div className="product_price">
                                    <h4>12000с</h4>
                                    <h4>9600с</h4>
                                </div>
                                <h3>Футболка / CHANEL</h3>
                                <p>Brand-Mixx</p>
                            </div>
                            <div className="product_block">
                                <div className="product_inblock">
                                    <div className="product_promotion">20%</div>
                                </div>
                                <div className="product_price">
                                    <h4>12000с</h4>
                                    <h4>9600с</h4>
                                </div>
                                <h3>Футболка / CHANEL</h3>
                                <p>Brand-Mixx</p>
                            </div>
                        </div>
                        <a href="#"
                        >Показать еще товары
                            <img src="img-Promotion/Arrow 1.svg" alt=""
                            />
                        </a>
                    </div>
                </div>
            </section>
            <section className="insta">
                <div className="container">
                    <div className="insta_info">
                        <p>
                            СКИДКА 5% <br/>
                            ПОДПИСЧИКАМ <br/>
                            INSTAGRAM
                        </p>
                        <div className="insta_logo">
                            <img src="img-Promotion/image 38.svg" alt=""/>
                            <h2>Online <span>Bazar</span></h2>
                        </div>
                    </div>
                </div>
            </section>
            <Footer/>
        </div>
    );
};

export default PromotionPage;