import React from 'react';
import '../../Montserrat/stylesheet.css'
import "./PageMain.css"
import "./reset.css"
import Header from "../ThreeComponents/Header/Header";
import Main from "../ThreeComponents/Main/Main";
import Footer from "../ThreeComponents/Footer/Footer";

const PageMain = () => {
    return (
        <div>
            <Header/>
            <div className="header">
                <div className="header_banner">
                    <div className="container">
                        <div className="header_info">
                            <p>Женская коллекция 2021</p>
                            <h1>НОВЫЙ СЕЗОН</h1>
                            <a href="#">КУПИТЬ СЕЙЧАС</a>
                            <div className="header_img">
                                <img src="img/image 12.svg" alt=""/>
                            </div>
                            <div className="header_block">
                                <img src="img/Arrow 3.svg" alt=""/>

                                <div className="header_ellipses">
                                    <div className="header_ellipse header_active"></div>
                                    <div className="header_ellipse"></div>
                                    <div className="header_ellipse"></div>
                                    <div className="header_ellipse"></div>
                                    <div className="header_ellipse"></div>
                                </div>
                                <img src="img/Arrow 2.svg" alt=""/>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <Main/>
            <Footer/>
        </div>
    );
};

export default PageMain;