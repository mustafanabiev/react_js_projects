import './App.css';
import '../Montserrat/stylesheet.css'
import React from 'react';
import PageMain from "../components/PageMain/PageMain";
import {BrowserRouter, Route, Routes} from "react-router-dom";

const App = () => {
    return (
        <BrowserRouter>
            <Routes>
                {/*<Route path="/aaaa" element={<PromotionPage/>}/>*/}
                <Route path="/" element={<PageMain/>}/>
            </Routes>
        </BrowserRouter>

    );
};

export default App;
